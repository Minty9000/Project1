package com.cs336.pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ApplicationDB {
	
	public ApplicationDB(){
		
	}

	public Connection getConnection(){
		String connectionUrl = "jdbc:mysql://localhost:3306/myprojectdb";
		Connection connection = null;
		try {
		    Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (Exception e) {
		    e.printStackTrace();
		}
		try {
		    connection = DriverManager.getConnection(connectionUrl, "root", "a13579");
		    // If your root password is NOT blank, put the real password instead of ""
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		return connection;
	}


	public void closeConnection(Connection connection){
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public static void main(String[] args) {
		ApplicationDB dao = new ApplicationDB();
		Connection connection = dao.getConnection();
		
		System.out.println(connection);		
		dao.closeConnection(connection);
	}
	
	

}
