package com.cs336.pkg;

public class Station {
	public int sid;
    public String name;
    public String city;
    public String state;

    public Station(int sid, String name, String city, String state) {
        this.sid = sid;
        this.name = name;
        this.city = city;
        this.state = state;
    }
}
