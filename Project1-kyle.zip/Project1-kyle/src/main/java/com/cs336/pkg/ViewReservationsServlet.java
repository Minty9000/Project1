package com.cs336.pkg;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ViewReservationsServlet")
public class ViewReservationsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<Reservation> currentReservations = new ArrayList<>();
        List<Reservation> pastReservations = new ArrayList<>();

        try (Connection con = new ApplicationDB().getConnection()) {
            String sql =
                "SELECT r.reservation_id, t.name AS train_name, os.name AS origin, ds.name AS destination, " +
                "ts.start_time, ts.end_time, r.passenger_type, r.round_trip, r.fare, r.status " +
                "FROM reservations r " +
                "JOIN users u ON r.user_id = u.id " +
                "JOIN train_schedules ts ON r.schedule_id = ts.schedule_id " +
                "JOIN trains t ON ts.train_id = t.train_id " +
                "JOIN stations os ON ts.origin_station_id = os.sid " +
                "JOIN stations ds ON ts.destination_station_id = ds.sid " +
                "WHERE u.username = ? " +
                "ORDER BY ts.start_time DESC";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();
                Timestamp now = new Timestamp(System.currentTimeMillis());
                while (rs.next()) {
                    Reservation res = new Reservation();
                    res.setReservationId(rs.getInt("reservation_id"));
                    res.setTrainName(rs.getString("train_name"));
                    res.setOrigin(rs.getString("origin"));
                    res.setDestination(rs.getString("destination"));
                    res.setStartTime(rs.getTimestamp("start_time"));
                    res.setEndTime(rs.getTimestamp("end_time"));
                    res.setPassengerType(rs.getString("passenger_type"));
                    res.setRoundTrip(rs.getBoolean("round_trip"));
                    res.setFare(rs.getBigDecimal("fare"));
                    String dbStatus = rs.getString("status");

                    // Dynamically set display status for expired "active" reservations
                    if ("active".equals(dbStatus) && res.getEndTime().before(now)) {
                        res.setStatus("past"); // Change status for display
                        pastReservations.add(res);
                    } else if ("active".equals(dbStatus) && res.getEndTime().after(now)) {
                        res.setStatus("active");
                        currentReservations.add(res);
                    } else {
                        // cancelled or any other status
                        res.setStatus(dbStatus);
                        pastReservations.add(res);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("currentReservations", currentReservations);
        request.setAttribute("pastReservations", pastReservations);
        request.getRequestDispatcher("viewReservations.jsp").forward(request, response);
    }
}
