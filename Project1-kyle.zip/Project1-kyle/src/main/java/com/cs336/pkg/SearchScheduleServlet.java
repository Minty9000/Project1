package com.cs336.pkg;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SearchScheduleServlet")
public class SearchScheduleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String origin = request.getParameter("origin");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date");
        String sort = request.getParameter("sort");

        List<TrainSchedule> schedules = new ArrayList<>();
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();

        String baseSql = "SELECT ts.schedule_id, t.name AS train_name, tl.name AS line_name, " +
                "os.name AS origin, ds.name AS destination, ts.start_time, ts.end_time, ts.fare " +
                "FROM train_schedules ts " +
                "JOIN trains t ON ts.train_id = t.train_id " +
                "JOIN transit_lines tl ON ts.transit_line_id = tl.transit_line_id " +
                "JOIN stations os ON ts.origin_station_id = os.sid " +
                "JOIN stations ds ON ts.destination_station_id = ds.sid " +
                "WHERE os.name = ? AND ds.name = ? AND DATE(ts.start_time) = ? ";

        String orderBy = "ORDER BY ts.start_time"; // default

        if ("end_time".equals(sort)) {
        	orderBy = "ORDER BY ts.end_time";
        } else if ("fare".equals(sort)) {
        	orderBy = "ORDER BY ts.fare";
        }

        String sql = baseSql + orderBy;

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, origin);
            ps.setString(2, destination);
            ps.setString(3, date);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                TrainSchedule ts = new TrainSchedule();
                ts.setScheduleId(rs.getInt("schedule_id"));
                ts.setTrainName(rs.getString("train_name"));
                ts.setLineName(rs.getString("line_name"));
                ts.setOrigin(rs.getString("origin"));
                ts.setDestination(rs.getString("destination"));
                ts.setStartTime(rs.getTimestamp("start_time"));
                ts.setEndTime(rs.getTimestamp("end_time"));
                ts.setFare(rs.getBigDecimal("fare"));

                // ==== Fetch stops for this schedule ====
                List<Stop> stops = new ArrayList<>();
                String stopSql = "SELECT s.name, ss.stop_time FROM schedule_stops ss " +
                                 "JOIN stations s ON ss.station_id = s.sid " +
                                 "WHERE ss.schedule_id = ? ORDER BY ss.stop_time";
                try (PreparedStatement stopPs = con.prepareStatement(stopSql)) {
                    stopPs.setInt(1, ts.getScheduleId());
                    try (ResultSet stopRs = stopPs.executeQuery()) {
                        while (stopRs.next()) {
                            Stop stop = new Stop();
                            stop.setStationName(stopRs.getString("name"));
                            stop.setStopTime(stopRs.getTimestamp("stop_time"));
                            stops.add(stop);
                        }
                    }
                }
                ts.setStops(stops); // Add stops to this schedule
                // ==== End fetching stops ====

                schedules.add(ts);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.closeConnection(con);
        }

        request.setAttribute("schedules", schedules);
        request.getRequestDispatcher("results.jsp").forward(request, response);
    }
}
