package com.cs336.pkg;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ReserveServlet")
public class ReserveServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int scheduleId = Integer.parseInt(request.getParameter("schedule_id"));
        String passengerType = request.getParameter("passenger_type");
        boolean roundTrip = request.getParameter("round_trip") != null;

        // Step 1: Get user_id from username
        int userId = -1;
        try (Connection con = new ApplicationDB().getConnection()) {
            String sql = "SELECT id FROM users WHERE username = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    userId = rs.getInt("id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Step 2: Get original fare from train_schedules
        BigDecimal fare = BigDecimal.ZERO;
        try (Connection con = new ApplicationDB().getConnection()) {
            String sql = "SELECT fare FROM train_schedules WHERE schedule_id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, scheduleId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    fare = rs.getBigDecimal("fare");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Step 3: Calculate discount
        double discount = 0.0;
        switch (passengerType) {
            case "child":
            case "disabled":
                discount = 0.5; // 50% off
                break;
            case "senior":
                discount = 0.3; // 30% off
                break;
            default:
                discount = 0.0; // No discount
        }
        fare = fare.multiply(BigDecimal.valueOf(1 - discount));
        if (roundTrip) {
            fare = fare.multiply(BigDecimal.valueOf(2));
        }
        // *** Make sure fare is always 2 decimals for currency ***
        fare = fare.setScale(2, java.math.RoundingMode.HALF_UP);

        // Step 4: Insert reservation (use user_id not username)
        try (Connection con = new ApplicationDB().getConnection()) {
            String sql = "INSERT INTO reservations (user_id, schedule_id, reservation_date, passenger_type, round_trip, status, fare) " +
                         "VALUES (?, ?, NOW(), ?, ?, 'active', ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, userId);
                ps.setInt(2, scheduleId);
                ps.setString(3, passengerType);
                ps.setBoolean(4, roundTrip);
                ps.setBigDecimal(5, fare);

                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect to reservation list or confirmation page
        response.sendRedirect("ViewReservationsServlet");
    }
}

