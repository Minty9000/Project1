package com.cs336.pkg;

import java.sql.Timestamp;

public class Stop {
    private String stationName;
    private Timestamp stopTime;

    public String getStationName() { return stationName; }
    public void setStationName(String stationName) { this.stationName = stationName; }

    public Timestamp getStopTime() { return stopTime; }
    public void setStopTime(Timestamp stopTime) { this.stopTime = stopTime; }
}
