package com.cs336.pkg;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CancelReservationServlet")
public class CancelReservationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String reservationIdStr = request.getParameter("reservation_id");
        if (reservationIdStr != null) {
            int reservationId = Integer.parseInt(reservationIdStr);

            try (Connection con = new ApplicationDB().getConnection()) {
                String sql = "UPDATE reservations SET status = 'cancelled' WHERE reservation_id = ?";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, reservationId);
                    ps.executeUpdate();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Redirect back to the reservations page
        response.sendRedirect("ViewReservationsServlet");
    }
}
